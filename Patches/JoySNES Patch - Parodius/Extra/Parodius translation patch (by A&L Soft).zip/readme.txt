Parodius
English Translation Patch (ROM)

This patch translates the Parodius
MSX ROM image to English. This translation
was made by A&L Soft.

http://www.alsoftware.com.br/adrianpage/index.php?page=msxsoft

This translation patch made by Spinner 8 for
exclusive use of the Whirlpool.

http://donut.parodius.com

Neither Spinner 8 nor the Whirlpool take any
credit for the translation, nor do we take
responsibility for it in any way.

This translation was originally distributed
in ROM format as a completely translated
game, but can not be hosted on the Whirlpool
due to it containing copyrighted game data.

Please do not distribute this patch in any
way whatsoever. This is intended solely for
the use of the Whirlpool and its users. If
you would like to have an IPS patch for your
own site, please make your own or use the
full ROM available at most other download
sites.

parodius_for_flashrom.ips is the patch for LPE FlashROM (and SCC in slot 2)